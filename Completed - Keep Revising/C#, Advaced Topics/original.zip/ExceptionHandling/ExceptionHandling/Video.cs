﻿namespace ExceptionHandling
{
    public class Video
    {
    }
}