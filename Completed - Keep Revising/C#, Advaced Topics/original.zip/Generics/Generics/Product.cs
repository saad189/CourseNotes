﻿namespace Generics
{
    public class Product
    {
        public string Title { get; set; }
        public float Price { get; set; }
    }
}