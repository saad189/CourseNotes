﻿namespace Generics
{
    public class Book : Product
    {
        public string Isbn { get; set; }
    }
}