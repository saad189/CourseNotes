﻿
namespace Linq
{
    public class Book
    {
        public string Title { get; set; }
        public float Price { get; set; }
    }
}