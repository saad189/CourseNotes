

namespace System
{
    public class String
    {
        public void Shorten(int numberOfWords)
        {


        }

        public int Add(int a, int b)
        {
            return a + b;
        }


    }

    public class MessageArgs
    {
    }
}


